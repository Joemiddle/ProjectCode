package layout;


import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


import com.example.tutorial.Questions;
import com.example.tutorial.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class Quiz1Fragment extends Fragment {

    private TextView Question;

    private ArrayList<Questions> questionlist;
    private Button submit;

    private RadioButton ans1, ans2, ans3, ans4;
    private RadioGroup group;
    private String answer;

    private int index;

    //private FirebaseDatabase choice1, choice2, choice3, choice4, dbquestion, dbanswer;

    public Quiz1Fragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_quiz1, container, false);
        group = (RadioGroup) view.findViewById(R.id.group);

        ans1 = (RadioButton) view.findViewById(R.id.ans1);
        ans2 = (RadioButton) view.findViewById(R.id.ans2);
        ans3 = (RadioButton) view.findViewById(R.id.ans3);
        ans4 = (RadioButton) view.findViewById(R.id.ans4);

        Question = (TextView) view.findViewById(R.id.question);

        submit = (Button) view.findViewById(R.id.submit);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (this.rightanswer) {
                    Toast.makeText(getActivity(), "Correct Answer!", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(getActivity(), "Incorrect Answer!", Toast.LENGTH_SHORT).show();
                }
            }

                public void rightanswer(){

                    String id = group.getCheckedRadioButtonId();
                    id.
            }



        });

        DatabaseReference ref = FirebaseDatabase.getInstance().getReferenceFromUrl("https://projectcode-c86ed.firebaseio.com/Tutorials/Tutorial 1/");

        ref.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                questionlist = new ArrayList<Questions>();
                for (DataSnapshot Snap : dataSnapshot.getChildren()){
                    questionlist.add(Snap.getValue(Questions.class));
                }
                index = 1;
                Display(index);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            //not being used
            }
        });

        return view;
    }

    private void Display(int index){

        Question.setText(questionlist.get(index).getQuestion());
        ans1.setText(questionlist.get(index).getPA1());
        ans2.setText(questionlist.get(index).getPA2());
        ans3.setText(questionlist.get(index).getPA3());
        ans4.setText(questionlist.get(index).getPA4());
        group.clearCheck();
    }


}
